import {loadModule} from './spelling-tools/node_modules/hunspell-asm/dist/cjs/index.js';
const fold=s=>s.normalize('NFD').replace(/[\u0300-\u036f]/g,'');
const dictionaries={},accents={};
const ready=(async()=>{const factory=await loadModule({timeout:20000});for(const [lang,data] of Object.entries(RAW)){
 const encode=new TextEncoder();dictionaries[lang]=factory.create(factory.mountBuffer(encode.encode(data.aff)),factory.mountBuffer(encode.encode(data.dic)));
 const map=new Map();for(const line of data.dic.split(/\r?\n/).slice(1)){const word=line.split(/[\/\s]/)[0].toLocaleLowerCase(),key=fold(word);if(key!==word){if(!map.has(key))map.set(key,new Set());map.get(key).add(word);}}accents[lang]=map;
 }self.postMessage({ready:true});})();
const common={pt:{estetico:'estético',estetica:'estética',nescessario:'necessário',nescessaria:'necessária',nescessidade:'necessidade',concerteza:'com certeza',excessão:'exceção',excessao:'exceção',dificil:'difícil',facil:'fácil',tambem:'também',voce:'você',nao:'não',informacao:'informação',observacao:'observação',correcao:'correção'},en:{recieve:'receive',recieved:'received',recieving:'receiving',teh:'the',adn:'and',definately:'definitely',seperate:'separate',adress:'address',occured:'occurred',occurrance:'occurrence',becuase:'because',wierd:'weird',acheive:'achieve',tomorow:'tomorrow'},es:{nesesario:'necesario',nesesaria:'necesaria',nesecito:'necesito',tambien:'también',informacion:'información',observacion:'observación',correccion:'corrección',estetico:'estético',estetica:'estética',dificil:'difícil',facil:'fácil',haciamos:'hacíamos'}};
const cached=new Map();
function analyze(word,language){
 const key=word.toLocaleLowerCase(),codes=language==='auto'?['pt','en','es']:[language];
 if(!/^[\p{L}]{2,60}$/u.test(key)||!codes.every(l=>dictionaries[l]))return {replacement:null,suggestions:[]};
 const cacheKey=language+':'+key;if(cached.has(cacheKey))return cached.get(cacheKey);
 const main=codes[0],dict=dictionaries[main];
 // Full Hunspell dictionaries apply their own affix/conjugation rules at query time.
 const valid=dict.spell(key);const primary=dict.suggest(key);
 const accentChoices=[...new Set([...(accents[main].get(fold(key))||[]),...primary.filter(s=>s.toLocaleLowerCase()!==key&&fold(s.toLocaleLowerCase())===fold(key))])].filter(s=>dict.spell(s));
 let result;
 if(valid){result={replacement:null,suggestions:accentChoices.filter(s=>s!==key),valid:true};}
 else if(accentChoices.length===1){result={replacement:accentChoices[0],suggestions:[]};}
 else if(accentChoices.length>1){const ranked=primary.filter(s=>accentChoices.includes(s));result={replacement:ranked[0]||null,suggestions:ranked.length?[]:accentChoices};}
 else if(codes.some(l=>common[l]?.[key]&&dictionaries[l].spell(common[l][key]))){result={replacement:codes.map(l=>common[l]?.[key]).find(Boolean),suggestions:[]};}
 else if(codes.slice(1).some(l=>dictionaries[l].spell(key))){result={replacement:null,suggestions:primary.slice(0,5),valid:true};}
 else{
  let choices=primary;
  if(language==='auto'){
   const other=codes.slice(1).flatMap(l=>dictionaries[l].suggest(key));
   const otherAccents=other.filter(s=>fold(s.toLocaleLowerCase())===fold(key));
   if(new Set(otherAccents).size===1)return {replacement:otherAccents[0],suggestions:[]};
   choices=[...new Set([...choices,...other])];
  }
  result={replacement:choices.length===1?choices[0]:null,suggestions:choices.slice(0,8)};
 }
 if(cached.size>2000)cached.clear();cached.set(cacheKey,result);return result;
}
self.onmessage=async e=>{const {id,word,language}=e.data;try{await ready;self.postMessage({id,word,...analyze(word,language||'auto')});}catch{self.postMessage({id,word,error:true,replacement:null,suggestions:[]});}};
ready.catch(()=>self.postMessage({error:true}));

